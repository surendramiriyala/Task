export const environment = {
  production: true,
  cognito:{
    userPoolId: 'ap-northeast-1_JOSF1axFx',
    userPoolWebClientId:'6mbtjtrt4ee75b3bco86otr7uv'

}
};

