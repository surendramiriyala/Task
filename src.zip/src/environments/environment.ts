export const environment = {
  production: false,
  cognito:{
    userPoolId: 'ap-northeast-1_JOSF1axFx',
    userPoolWebClientId:'6mbtjtrt4ee75b3bco86otr7uv'

}

}