import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CourseService } from '../course.service';
import { SignupComponent } from '../signup/signup.component';
import { User } from '../model/user';
import { CognitoService } from '../cognito.service';


@Component({
  selector: 'app-personaldetails',
  templateUrl: './personaldetails.component.html',
  styleUrls: ['./personaldetails.component.css']
})
export class PersonaldetailsComponent implements OnInit {
  constructor(private servicets:CourseService) {
    
  }

  Users:any

  ngOnInit(): void {

    this.servicets.getPersonalDetails().subscribe((data:any)=>{
      console.log(data)
      this.Users=data
   
  })
}
}
  
  

  
  
  
