import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CognitoService } from './cognito.service';
import { CourseService } from './course.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'YTP Learning';
  showAlert: any;
  constructor(private router: Router,private cognitoservice: CognitoService, private courseservice:CourseService) { }

  ngOnInit(): void { 
    
    this.getUserDetails();
  }
  private getUserDetails(){
    this.cognitoservice.getUser().then((user:any)=>{
      if(user){
        //logged in 
        console.log(user)
      }
      else{
        this.router.navigate(['/signin']); 
      }
    })
  }
  signOutWithCognito(){
    alert(' You have logged out YTP learning ')
    this.cognitoservice.signOut().then(()=>{
      this.router.navigate(['/signin'])
    })
  }
}
