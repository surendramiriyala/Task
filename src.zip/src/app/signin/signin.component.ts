import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CognitoService } from '../cognito.service';
import { User } from '../model/user';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  
  user:User | undefined;
  alertMessage:string='';
  showAlert:boolean=false;
  isForgotPassword:boolean=false;
  newpassword:string='';

   
  constructor(private router :Router,private cognitoservice:CognitoService) { }
  
  ngOnInit(): void {
    this.user={} as User;
  }



  signInWithCognito(){
    if(this.user && this.user.email &&  this.user.password)
    {
      this.cognitoservice.singIn(this.user).then(()=>{
         this.router.navigate(['/'])
      })
      .catch((error:any)=>{
        this.displayAlert(error.message)

      })
    }
    else{
      this.displayAlert("please enter valid email or password")
    } 
  }


  forgorPasswordClicked(){
    if(this.user && this.user.email){
      this.cognitoservice.forgotPassword(this.user).then(()=>{
        this.isForgotPassword=true;
      })
      .catch((error:any)=>{
        this.displayAlert(error.message)
      })     

    }
    else{
        this.displayAlert("enter a valid email addresss")
    }
  }
  newPasswordSubmit()
  {
    if(this.user && this.user.email && this.newpassword.trim().length!=0){
      this.cognitoservice.forgotPasswordSubmit(this.user,this.newpassword.trim()).then(()=>{
         this.displayAlert("password updated")
         this.isForgotPassword=false;
      }).catch((error:any)=>{
        this.displayAlert(error.message)
      })
    }else{
      this.displayAlert("please enter valid input")
    }
  }




  private displayAlert(message:string)
  {
    this.alertMessage=message;
    this.showAlert=true;
  }
}
