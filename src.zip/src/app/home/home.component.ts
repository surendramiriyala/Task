import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CognitoService } from '../cognito.service';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
showAlert: any;
coursecatlog:any;

  constructor(private router: Router,private cognitoservice: CognitoService, private courseservice:CourseService) { }

  ngOnInit(): void { 
    
    //this.getUserDetails();

    this.courseservice.getCatlagDetails().subscribe((data:any)=>{
      console.log(data)
      this.coursecatlog=data})
    
      
  }
  
}
