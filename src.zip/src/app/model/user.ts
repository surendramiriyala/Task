export interface User {
    email: string;
    password :string;
    
    givenname :string ;
    familyname :string ;
    showpassword:boolean;
    code : string ;
}
