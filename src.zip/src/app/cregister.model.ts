export class user{
    course_name?:string
    Date_of_reg?:Date
    mobilenumber?:string
    dob?:Date
    loc?:string
    profession?:string
    qua?:string
    
}