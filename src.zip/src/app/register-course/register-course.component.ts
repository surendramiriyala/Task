import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first } from 'rxjs';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-register-course',
  templateUrl: './register-course.component.html',
  styleUrls: ['./register-course.component.css']
})
export class RegisterCourseComponent implements OnInit {
registerFormControl: any;
submitted: any;


  
  ngOnInit(): void {

  }
  angForm: FormGroup;
  

  constructor(
    private fb: FormBuilder,
    private route: Router,
    private register :CourseService
  ) {

    this.angForm = this.fb.group({
       course_name: [' ', [Validators.required,Validators.minLength(3),Validators.maxLength(20)]],
      Date_of_reg: [' ', [Validators.required,]],
      mobilenumber: [' ', [Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
    
      loc: [' ', [Validators.required,Validators.minLength(2),Validators.maxLength(25)]],
      profession: [' ', [Validators.required,]],
     qua:['',[Validators.required,]]
     

         
    });
  }
  postdata(forms: any) {
    console.log(forms.value)  
   this.register.adduser

   (this.angForm.value.course_name,
    this.angForm.value.Date_of_reg ,
    this.angForm.value.mobilenumber,
    this.angForm.value.loc,
    this.angForm.value.profession,
    this.angForm.value.qua,
    
 ).pipe(first()).subscribe((data) =>{
  console.log(data)
  this.route.navigate(['catlog']);
 }, (error)=>{}
 )
  }

}
