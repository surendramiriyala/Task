import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-startcourse',
  templateUrl: './startcourse.component.html',
  styleUrls: ['./startcourse.component.css']
})
export class StartcourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
