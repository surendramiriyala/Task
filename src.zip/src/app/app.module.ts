import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { SigninComponent } from './signin/signin.component';
import { MessageModalComponent } from './message-modal/message-modal.component';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CognitoService } from './cognito.service';
import { NavbarComponent } from './navbar/navbar.component';
import { HttpClientModule } from '@angular/common/http';
// import { DataService } from './data.service';
// import { RegistrationComponent } from './registration/registration.component';
// import { ViewdetailsComponent } from './viewdetails/viewdetails.component';
// import { AddressService } from './address.service';
// import { EditComponent } from './edit/edit.component';
import { RegisterCourseComponent } from './register-course/register-course.component';
import { CoursecatlogComponent } from './coursecatlog/coursecatlog.component';
import { CourseService } from './course.service';
import { PersonaldetailsComponent } from './personaldetails/personaldetails.component';
import { ProgressComponent } from './progress/progress.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { StartcourseComponent } from './startcourse/startcourse.component';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    HomeComponent,
    SigninComponent,
    MessageModalComponent,
    NavbarComponent,
    // RegistrationComponent,
    // ViewdetailsComponent,
    // EditComponent,
    RegisterCourseComponent,
    CoursecatlogComponent,
    PersonaldetailsComponent,
    ProgressComponent,
    StartcourseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    
    HttpClientModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule
    
    
  ],
  providers: [CognitoService ,CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
