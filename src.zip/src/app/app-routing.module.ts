import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CoursecatlogComponent } from './coursecatlog/coursecatlog.component';

import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PersonaldetailsComponent } from './personaldetails/personaldetails.component';
import { ProgressComponent } from './progress/progress.component';
import { RegisterCourseComponent } from './register-course/register-course.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { StartcourseComponent } from './startcourse/startcourse.component';

const routes: Routes = [
{path:'',component:HomeComponent},
{path:'navbar',component:NavbarComponent},
{path:'signup',component:SignupComponent},
{path:'signin',component:SigninComponent},
{path:'home',component:HomeComponent},
{path:'register',component:RegisterCourseComponent},
{path:'catlog',component:CoursecatlogComponent},
{path:'personal',component:PersonaldetailsComponent},
{path:'progress',component:ProgressComponent},
{path:'startcourse',component:StartcourseComponent},

{path:'**',component:SigninComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

