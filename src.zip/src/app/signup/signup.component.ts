import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { first } from 'rxjs';
import { CognitoService } from '../cognito.service';
import { CourseService } from '../course.service';
import { User } from '../model/user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user:User | undefined;
  isConfirm:boolean=false;
  alertMessage:string='';
  showAlert:boolean=false;
  isForgotPassword: any;

  
    constructor(private router :Router, private cognitoservice:CognitoService, private apiservice:CourseService) { }

  ngOnInit(): void {
    this.user={} as User;
    this.isConfirm =false;
  }
  


  public signUpWithCognito(){
    if(this.user && this.user.email && this.user.password){
      this.cognitoservice.signUp(this.user).then(()=>{
        this.isConfirm=true;
      }).catch((error:any)=>{
   this.displayAlert(error.message)
      })
    }
    else{
      this.displayAlert(" Missing email  or password  ")
    }

  }
  public confirmSignup(){
    if(this.user){
      this.cognitoservice.confirmSignup(this.user)
      .then(()=>{
        // this.router.navigate(['/signin'])
      })
      .catch((error:any)=>{
        this.displayAlert(error.message)
      })
      this.apiservice.adduser1(this.user).pipe(first()).subscribe((data)=>{
        this.router.navigate(['/signin'])
      })

    }
    else{
      this.displayAlert("Missing user information")
    }
  }
  private displayAlert(message:string){
    this.alertMessage=message;
    this.showAlert=true;


}


}
