import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoursecatlogComponent } from './coursecatlog.component';

describe('CoursecatlogComponent', () => {
  let component: CoursecatlogComponent;
  let fixture: ComponentFixture<CoursecatlogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoursecatlogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CoursecatlogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
