import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-coursecatlog',
  templateUrl: './coursecatlog.component.html',
  styleUrls: ['./coursecatlog.component.css']
})
export class CoursecatlogComponent implements OnInit {


  Users:any
searchText: any;
  constructor(private register:CourseService, private router: Router){}

  ngOnInit(): void {
    this.register.listRegistrations().subscribe((data:any)=>{
      console.log(data)
      this.Users=data
    
  })

}

  delete_course(id:any):void{
    alert("are you sure to delete")
    console.log(id)
    this.register.deleteCourse(id).subscribe(data=>{
      // this.products=this.products.filter((u:any)=> u !==pro_id);
      //this.router.navigate(['/list-product'])
      
               this.register.listRegistrations().subscribe((data:any)=>{
               this.Users=data
   
  
    });
  })

  }
}

