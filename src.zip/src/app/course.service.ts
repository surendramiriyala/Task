import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { user } from './cregister.model';
import { User } from './model/user';


@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private  httpclient: HttpClient) { }

  baseUrl:string="http://127.0.0.1:5000/"
  http: any;


  public adduser(course_name:any,Date_of_reg:any,mobilenumber:any,loc:any,profession:any,qua:any){
      
      return this.httpclient.post<any>(this.baseUrl+'ytplearning', {
        course_name,Date_of_reg,mobilenumber,loc,profession,qua}).pipe(map((user:any)=> {
        return user;  } ))
    }

  public listRegistrations()
  {
    return this.httpclient.get<user[]>(this.baseUrl+'ytplearning');
  }
  
  deleteCourse(id:any)
  {
     return this.httpclient.delete(this.baseUrl+'ytplearning/'+id);
    
  }
  getdetailsbyid(id:number)
  {
    return this.httpclient.get<user>(this.baseUrl+'ytplearning/'+id)
  }

  public adduser1(user:any){
      
    return this.httpclient.post<any>(this.baseUrl+'ytplearning-profile', {'fname':user.familyname,'lanme':user.givenname,'email':user.email,'password':user.password

    }).pipe(map((user:any)=> {
      return user;  } ))
  }
  getPersonalDetails()
  {
    return this.httpclient.get<User>(this.baseUrl+'ytplearning-profile')
  } 

  getCatlagDetails()
  {
    return this.httpclient.get<User>(this.baseUrl+'ytplearning-catalog')
  } 

}
